"""Page Object for Login Page"""

"""Define all the elements and methods related to Login page"""


class LoginPage:
    def __init__(self, driver):
        self.driver = driver
        self.driver.instance.implicitly_wait(10)
        self.skip_sign_in_btn = "com.amazon.mShop.android.shopping:id/skip_sign_in_button"

    def click_login_skip(self):
        self.driver.instance.find_element_by_id(self.skip_sign_in_btn).click()

