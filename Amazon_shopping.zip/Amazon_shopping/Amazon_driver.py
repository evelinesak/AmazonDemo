"""Created Driver for this demo app"""
from appium import webdriver


class Driver:
    def __init__(self):
        desired_cap = {
            "deviceName": "emulator-5554",
            #"deviceName": "ZX1D642F7B",
            "platformName": "Android",
            "app": "C:\\Users\\evelines\\Desktop\\Mobile_app\\Amazon_shopping.apk",
            "noReset": "true",
            "automationName": "UiAUtomator",
            "appPackage": "com.amazon.mShop.android.shopping",
            "appActivity": "com.amazon.mShop.home.HomeActivity"

        }
        self.instance = webdriver.Remote("http://localhost:4723/wd/hub", desired_cap)

    def tearDown(self):
        self.instance.quit()





