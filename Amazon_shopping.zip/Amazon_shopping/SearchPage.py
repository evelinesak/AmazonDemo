"""Page Object for Search Page"""


"""Define all the elements and methods related to Search page"""


class SearchPage:
    def __init__(self, driver):
        self.driver = driver
        self.driver.instance.implicitly_wait(20)
        self.search_bar = "com.amazon.mShop.android.shopping:id/rs_search_src_text"
        self.search_text = "com.amazon.mShop.android.shopping:id/rs_search_src_text"
        self.signin_btn = "gwm-SignIn-button"
        self.random_product = "android.widget.TextView"
        self.select_product = '//android.widget.TextView[@text="{}"]'

    def verify_search_page(self):
        self.driver.instance.el1 = self.driver.instance.find_element_by_id(self.signin_btn)
        if self.driver.instance.el1:
            assert True
        else:
            assert False

    def search(self):
        self.driver.instance.product = self.driver.instance.find_element_by_id(self.search_bar)
        self.driver.instance.product.click()
        self.driver.instance.product.clear().send_keys("65-inch tv")

    def random_selection(self):
        self.driver.instance.sel = self.driver.instance.find_elements_by_class_name(self.random_product)[2]
        self.driver.instance.sel.click()


