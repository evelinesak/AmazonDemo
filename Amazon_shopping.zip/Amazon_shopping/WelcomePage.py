"""Page Object for Login Page"""

import selenium.webdriver.support.ui as ui
from appium.webdriver.common.touch_action import TouchAction

"""Define all the elements and methods related to Welcome page"""


class WelcomePage:
    def __init__(self, driver):
        self.driver = driver
        self.driver.instance.implicitly_wait(20)
        self.already_customer_option = "login_accordion_header"
        self.continue_btn = "continue"

    def verify_welcome_page(self):
        if self.driver.instance.find_element_by_id(self.already_customer_option):
            assert True
        else:
            assert False

    def login_valid_user(self):
        self.driver.instance.wait = ui.WebDriverWait(self.driver, 5)
        self.driver.instance.continue1 = self.driver.instance.find_element_by_xpath('//android.widget.Button[@text="Continue"]')
        self.driver.instance.wait.until(lambda s: s.self.driver.instance.continue1)
        self.driver.instance.action = TouchAction(self.driver.instance)
        self.driver.instance.action.tap(element=None, x=337, y=668, count=1).perform()
