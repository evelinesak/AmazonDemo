"""This is Main program with test cases. We need to run this"""
import unittest
from appium import webdriver
from Amazon_driver import Driver
from time import sleep
from appium.webdriver.common.touch_action import TouchAction
from LoginPage import LoginPage
from WelcomePage import WelcomePage
from SearchPage import SearchPage


class AmazonTestCases(unittest.TestCase):
    def setUp(self):
        self.driver = Driver()

    def test_login_skip(self):
        login = LoginPage(self.driver)
        login.click_login_skip()
        search = SearchPage(self.driver)
        search.verify_search_page()

    def test_search(self):
        search = SearchPage(self.driver)
        search.search()
        search.random_selection()





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(AmazonTestCases)
    unittest.TextTestRunner(verbosity=2).run(suite)